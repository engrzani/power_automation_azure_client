# CheckAndAssignLicense.ps1
param(
  [Parameter(Mandatory=$true)][string] $UPN,
  [Parameter(Mandatory=$true)][string] $SkuSearch # e.g. "BUSINESS_BASIC" or "Business Basic" - script will try fuzzy match
)

Connect-MgGraph -Identity

$skus = Get-MgSubscribedSku -All
# fuzzy match: try SkuPartNumber then DisplayName
$sku = $skus | Where-Object { ($_.SkuPartNumber -match $SkuSearch) -or ($_.SkuPartNumber -like "*$SkuSearch*") -or ($_.SkuPartNumber -like "*BUSINESS*" -and $_.SkuPartNumber -like "*BASIC*") }
if (-not $sku) { $sku = $skus | Where-Object { $_.SkuPartNumber -like "*BASIC*" -and $_.SkuPartNumber -like "*BUSINESS*" } }

if (-not $sku) { Write-Output (@{ success = $false; message = "SKU not found in tenant. Run Get-MgSubscribedSku to inspect." } | ConvertTo-Json); exit 1 }

$available = $sku.PrepaidUnits.Enabled - $sku.ConsumedUnits
if ($available -le 0) {
  Write-Output (@{ success = $false; message = "No available licenses for $($sku.SkuPartNumber)." } | ConvertTo-Json)
  exit 1
}

# Assign license
$addLicenses = @(@{ skuId = $sku.SkuId })
try {
  Grant-MgUserLicense -UserId $UPN -AddLicenses $addLicenses -RemoveLicenses @()
  Write-Output (@{ success = $true; message = "License assigned" } | ConvertTo-Json)
} catch {
  Write-Output (@{ success = $false; message = $_.Exception.Message } | ConvertTo-Json)
  exit 1
}
