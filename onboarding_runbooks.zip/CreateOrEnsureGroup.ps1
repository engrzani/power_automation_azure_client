# CreateOrEnsureGroup.ps1
param(
  [string] $GroupName = "Accounts Team 1",
  [switch] $MailEnabled = $false
)

Connect-MgGraph -Identity
$existing = Get-MgGroup -Filter "displayName eq '$GroupName'" -ConsistencyLevel eventual -ErrorAction SilentlyContinue
if ($existing) {
  Write-Output (@{ success = $true; message = "Group exists"; groupId = $existing.Id; groupDisplayName = $existing.DisplayName } | ConvertTo-Json)
  return
}

$mailNickname = ($GroupName -replace '[^a-zA-Z0-9]','-').ToLower() + (Get-Random -Minimum 1 -Maximum 9999)
$group = New-MgGroup -DisplayName $GroupName -MailEnabled:$false -MailNickname $mailNickname -SecurityEnabled:$true -GroupTypes @()
Write-Output (@{ success = $true; message = "Group created"; groupId = $group.Id } | ConvertTo-Json)
