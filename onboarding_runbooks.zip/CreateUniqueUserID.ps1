# CreateUniqueUserID.ps1
param(
  [Parameter(Mandatory=$true)][string] $FirstName,
  [Parameter(Mandatory=$true)][string] $LastName,
  [Parameter(Mandatory=$true)][string] $Domain # e.g. "contoso.com"
)

Connect-MgGraph -Identity

function NormalizeName($s) {
  $s = $s.ToLower()
  return ($s -replace '[^a-z0-9\._-]','')
}

$base = "{0}.{1}" -f (NormalizeName $FirstName), (NormalizeName $LastName)
# search for collisions
$filter = "startswith(userPrincipalName,'$base')"
$existing = Get-MgUser -Filter $filter -ConsistencyLevel eventual -All

$unique = $base
if ($existing.Count -gt 0) {
  $numbers = @()
  foreach ($u in $existing) {
    $upn = ($u.UserPrincipalName -split "@")[0]
    if ($upn -eq $base) { $numbers += 0 }
    elseif ($upn -match "^${base}\.(\d+)$") { $numbers += [int]$matches[1] }
  }
  $n = 1
  while ($numbers -contains $n) { $n++ }
  $unique = "{0}.{1}" -f $base, $n
}

$upn = "$unique@$Domain"
$result = @{ UniqueID = $unique; UPN = $upn } | ConvertTo-Json
Write-Output $result
