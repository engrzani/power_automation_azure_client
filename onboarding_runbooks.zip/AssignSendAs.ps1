# AssignSendAs.ps1
param(
  [Parameter(Mandatory=$true)][string] $MailboxUPN, # the mailbox to grant sendas on
  [Parameter(Mandatory=$true)][string] $GroupIdentifier # group UPN or group display name
)

# For Exchange Online operations
# Connect using Managed Identity or app-only cert then Exchange
Connect-ExchangeOnline -ManagedIdentity

# If $GroupIdentifier is groupId, convert to SAM/UPN if necessary. Here we assume group UPN or display name.
try {
  Add-RecipientPermission -Identity $MailboxUPN -Trustee $GroupIdentifier -AccessRights SendAs -Confirm:$false
  Write-Output (@{ success = $true; message = "SendAs assigned via Add-RecipientPermission" } | ConvertTo-Json)
} catch {
  # fallback to Add-MailboxPermission
  try {
    Add-MailboxPermission -Identity $MailboxUPN -User $GroupIdentifier -AccessRights SendAs -InheritanceType All -Confirm:$false
    Write-Output (@{ success = $true; message = "SendAs assigned via Add-MailboxPermission" } | ConvertTo-Json)
  } catch {
    Write-Output (@{ success = $false; message = $_.Exception.Message } | ConvertTo-Json)
    exit 1
  }
}
