# CreateUser.ps1
param(
  [Parameter(Mandatory=$true)][string] $UPN,
  [Parameter(Mandatory=$true)][string] $DisplayName,
  [string] $GivenName,
  [string] $Surname,
  [string] $JobTitle,
  [string] $Department
)

Connect-MgGraph -Identity

# Idempotent: check if user exists
$user = Get-MgUser -UserId $UPN -ErrorAction SilentlyContinue
if ($user) {
  Write-Output (@{ success = $true; message = "User already exists"; userId = $user.Id } | ConvertTo-Json)
  return
}

# Create user with a temporary password; set to force password change
$passwordProfile = @{ forceChangePasswordNextSignIn = $true; password = ([System.Web.Security.Membership]::GeneratePassword(12,2)) }

$body = @{ accountEnabled = $true; displayName = $DisplayName; mailNickname = $UPN.Split('@')[0]; userPrincipalName = $UPN; givenName = $GivenName; surname = $Surname; passwordProfile = $passwordProfile }

$newUser = New-MgUser -BodyParameter $body
Write-Output (@{ success = $true; message = "User created"; userId = $newUser.Id } | ConvertTo-Json)
