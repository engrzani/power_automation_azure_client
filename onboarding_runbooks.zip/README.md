# Onboarding Runbooks & Power Automate Integration

This package contains idempotent PowerShell runbooks ready to import into Azure Automation, plus a README with guidance.

Files included:
- CreateUniqueUserID.ps1
- CreateUser.ps1
- CheckAndAssignLicense.ps1
- CreateOrEnsureGroup.ps1
- AddGroupMembers.ps1
- AssignSendAs.ps1

## Quick import steps
1. Upload each `.ps1` file to your Azure Automation Account as a PowerShell Runbook (PowerShell 7.2+ if available).
2. Install required modules in Automation: `Microsoft.Graph`, `ExchangeOnlineManagement`.
3. Configure a System Assigned Managed Identity or create a Service Principal with certificate.
4. Grant minimum roles to the identity: User Administrator, Groups Administrator (or Group.ReadWrite.All), License Administrator, Exchange Administrator (for Exchange actions).
5. Publish runbooks and create webhooks for each runbook you want Flow to call.
6. Update Power Automate flow to call the webhooks (HTTP POST) and parse JSON responses.
7. Test in a test tenant or with a test user and test group.

## Flow HTTP sample bodies
Example body for CreateUniqueUserID webhook:
```json
{ "FirstName": "John", "LastName": "Doe", "Domain": "contoso.com" }
```

Example body for CreateUser webhook:
```json
{ "UPN": "john.doe@contoso.com", "DisplayName": "John Doe", "GivenName": "John", "Surname": "Doe" }
```

Example body for CheckAndAssignLicense webhook:
```json
{ "UPN": "john.doe@contoso.com", "SkuSearch": "BUSINESS_BASIC" }
```

Example body for AddGroupMembers webhook:
```json
{ "GroupId": "00000000-0000-0000-0000-000000000000", "MemberUPNs": ["manager@contoso.com","mgradmin@contoso.com"] }
```

Example body for AssignSendAs webhook:
```json
{ "MailboxUPN": "john.doe@contoso.com", "GroupIdentifier": "Accounts Team 1" }
```

## Testing checklist
1. Submit a sample form with attachment.
2. Verify CreateUniqueUserID returns unique UPN.
3. Verify CreateUser creates user in AAD.
4. Verify CheckAndAssignLicense assigns license or returns failure if no seats.
5. Verify Accounts Team 1 exists and members are added.
6. Verify SendAs assigned for mailbox to the group.
7. Verify Teams posting includes the uploaded attachment link.
