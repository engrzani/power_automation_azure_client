# AddGroupMembers.ps1
param(
  [Parameter(Mandatory=$true)][string] $GroupId,
  [Parameter(Mandatory=$true)][string[]] $MemberUPNs
)

Connect-MgGraph -Identity
foreach ($u in $MemberUPNs) {
  try {
    $user = Get-MgUser -UserId $u -ErrorAction Stop
    New-MgGroupMemberByRef -GroupId $GroupId -BodyParameter @{ "@odata.id" = "https://graph.microsoft.com/v1.0/users/$($user.Id)" } -ErrorAction Stop
  } catch {
    Write-Warning "Failed to add $u: $_"
  }
}
Write-Output (@{ success = $true; message = "Members processed" } | ConvertTo-Json)
